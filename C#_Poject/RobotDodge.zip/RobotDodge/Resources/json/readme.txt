You can place json file in this folder for your program to read.
